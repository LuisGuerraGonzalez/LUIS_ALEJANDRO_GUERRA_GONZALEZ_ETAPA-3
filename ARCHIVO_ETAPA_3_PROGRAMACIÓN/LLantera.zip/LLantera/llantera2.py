import tkinter as tk
from tkinter import messagebox, simpledialog
from tkinter import ttk
import os
import hashlib
from datetime import datetime
from PIL import Image, ImageTk

import requests
from io import BytesIO

import os

# Crear carpeta de datos si no existe
CARPETA_DATOS = os.path.join(os.getcwd(), "datos_llantera")
os.makedirs(CARPETA_DATOS, exist_ok=True)

# Rutas automáticas relativas
RUTA_EMPLEADOS = os.path.join(CARPETA_DATOS, "empleados.txt")
RUTA_LLANTAS = os.path.join(CARPETA_DATOS, "llantas.txt")
RUTA_PEDIDOS = os.path.join(CARPETA_DATOS, "pedidos.txt")
RUTA_VENTAS_VENDEDOR = os.path.join(CARPETA_DATOS, "VentasVendedor.txt")
RUTA_TICKETS = os.path.join(CARPETA_DATOS, "tickets")
os.makedirs(RUTA_TICKETS, exist_ok=True)


# ----------------- Variables globales -----------------
empleados = []
llantas = []
pedidos = []
usuario = []
usuario_actual = None
ventas_vendedor = []
siguiente_venta = 1
siguiente_id = 1
siguiente_pedido = 1
intentos_fallidos = {}  # para bloqueo tras 3 intentos


# ----------------- Carga y guardado -----------------
def cargar_empleados():
    global siguiente_id
    if os.path.exists(RUTA_EMPLEADOS):
        with open(RUTA_EMPLEADOS, "r") as f:
            for line in f:
                partes = line.strip().split(',')
                if len(partes) != 4:
                    continue
                id_, nombre, puesto, clave = partes
                empleados.append({'id': int(id_), 'nombre': nombre, 'puesto': puesto, 'contrasena': clave})
                siguiente_id = max(siguiente_id, int(id_) + 1)

def guardar_empleado(emp):
    with open(RUTA_EMPLEADOS, "a") as f:
        f.write(f"{emp['id']},{emp['nombre']},{emp['puesto']},{emp['contrasena']}\n")


def cargar_llantas():
    if os.path.exists(RUTA_LLANTAS):
        with open(RUTA_LLANTAS, "r") as f:
            for line in f:
                parts = line.strip().split(',')
                if len(parts) == 10:
                    try:
                        llantas.append({
                            'marca': parts[0],
                            'modelo': parts[1],
                            'precio': float(parts[2]),
                            'stock': int(parts[3]),
                            'tipo_vehiculo': parts[4],
                            'tipo_uso': parts[5],
                            'ancho': int(parts[6]),
                            'perfil': int(parts[7]),
                            'diametro': int(parts[8]),
                            'caducidad': datetime.strptime(parts[9], "%Y-%m-%d").date()
                        })
                    except ValueError as e:
                        print(f"⚠ Error al cargar línea: {line.strip()} → {e}")


def guardar_llantas():
    with open(RUTA_LLANTAS, "w") as f:
        for l in llantas:
            f.write(f"{l['marca']},{l['modelo']},{l['precio']},{l['stock']},{l['tipo_vehiculo']},{l['tipo_uso']},{l['ancho']},{l['perfil']},{l['diametro']},{l['caducidad']}\n")

def cargar_pedidos():
    global siguiente_pedido
    if os.path.exists(RUTA_PEDIDOS):
        with open(RUTA_PEDIDOS, "r") as f:
            for line in f:
                partes = line.strip().split(',')
                if len(partes) == 6:
                    id_, proveedor, costo, estado, cantidad, modelo = partes
                    pedidos.append({
                        'id': int(id_),
                        'proveedor': proveedor,
                        'costo': float(costo),
                        'estado': estado,
                        'cantidad': int(cantidad),
                        'modelo': modelo
                    })
                    siguiente_pedido = max(siguiente_pedido, int(id_) + 1)
                else:
                    # Ignorar líneas mal formateadas o vacías
                    continue


def guardar_pedidos():

    with open(RUTA_PEDIDOS, "w") as f:
        for p in pedidos:
            f.write(f"{p['id']},{p['proveedor']},{p['costo']},{p['estado']},{p['cantidad']},{p['modelo']}\n")

def cargar_ventas_vendedor():
    global ventas_vendedor, siguiente_venta
    ventas_vendedor = []
    siguiente_venta = 0
    if os.path.exists(RUTA_VENTAS_VENDEDOR):
        with open(RUTA_VENTAS_VENDEDOR, "r", encoding="utf-8") as f:
            for line in f:
                partes = line.strip().split(',')
                if len(partes) == 8:
                    id_, vendedor_id, cliente, telefono, direccion, modelo, cantidad, total = partes
                    ventas_vendedor.append({
                        'id': int(id_),
                        'vendedor_id': int(vendedor_id),
                        'cliente': cliente,
                        'telefono': telefono,
                        'direccion': direccion,
                        'modelo': modelo,
                        'cantidad': int(cantidad),
                        'total': float(total)
                    })
                    if int(id_) > siguiente_venta:
                        siguiente_venta = int(id_)

def guardar_ventas_vendedor():
    with open("VentasVendedor.txt", "w", encoding="utf-8") as f:
        for v in ventas_vendedor:
            f.write(f"{v['id']},{v['vendedor_id']},{v['cliente']},{v['telefono']},{v['direccion']},{v['modelo']},{v['cantidad']},{v['total']}\n")


def registrar_venta_vendedor(vendedor_id):
    if not llantas:
        messagebox.showerror("Error", "No hay llantas disponibles en inventario.")
        return

    ventana = tk.Toplevel()
    ventana.title("Registrar Venta")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Registrar Venta", font=("Arial", 24, "bold"), bg="white").grid(row=0, column=0, columnspan=2, pady=20)

    modelos = [f"{l['marca']} {l['modelo']}" for l in llantas]
    combo_modelo = ttk.Combobox(marco, values=modelos, font=("Arial", 14), width=40, state="readonly")
    combo_modelo.grid(row=1, column=0, columnspan=2, pady=10)
    combo_modelo.current(0)

    campos = {
        "nombre_cliente": tk.Entry(marco, font=("Arial", 14), width=30),
        "teléfono": tk.Entry(marco, font=("Arial", 14), width=30),
        "dirección": tk.Entry(marco, font=("Arial", 14), width=30),
        "cantidad": tk.Entry(marco, font=("Arial", 14), width=30),
    }

    etiquetas = ["Nombre del cliente:", "Teléfono:", "Dirección:", "Cantidad:"]
    for i, (clave, entrada) in enumerate(campos.items(), start=2):
        tk.Label(marco, text=etiquetas[i-2], font=("Arial", 14), bg="white").grid(row=i, column=0, sticky="e", pady=10)
        entrada.grid(row=i, column=1, pady=10)

    def guardar_venta():
        global siguiente_venta, ventas_vendedor

        cliente = campos['nombre_cliente'].get().strip()
        telefono = campos['teléfono'].get().strip()
        direccion = campos['dirección'].get().strip()
        cantidad_text = campos['cantidad'].get().strip()
        seleccion = combo_modelo.get()

        if not cliente or not telefono or not direccion or not cantidad_text:
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
            return

        try:
            cantidad = int(cantidad_text)
            if cantidad <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Cantidad debe ser un número entero positivo.")
            return

        llanta = next((l for l in llantas if f"{l['marca']} {l['modelo']}" == seleccion), None)
        if not llanta:
            messagebox.showerror("Error", "Modelo no encontrado.")
            return

        if cantidad > llanta['stock']:
            messagebox.showerror("Error", f"Stock insuficiente. Disponible: {llanta['stock']}")
            return

        total = llanta['precio'] * cantidad
        siguiente_venta += 1

        venta = {
            'id': siguiente_venta,
            'vendedor_id': vendedor_id,
            'cliente': cliente,
            'telefono': telefono,
            'direccion': direccion,
            'modelo': seleccion,
            'cantidad': cantidad,
            'total': total
        }

        ventas_vendedor.append(venta)
        guardar_ventas_vendedor()
        llanta['stock'] -= cantidad
        guardar_llantas()

        # Crear ticket
        nombre_ticket = f"ticket_{siguiente_venta:04d}.txt"
        ruta_ticket = os.path.join(RUTA_TICKETS, nombre_ticket)
        with open(ruta_ticket, "w", encoding="utf-8") as f:
            f.write("=== Ticket de Venta ===\n")
            f.write(f"ID Venta: {siguiente_venta}\n")
            f.write(f"Vendedor ID: {vendedor_id}\n")
            f.write(f"Cliente: {cliente}\n")
            f.write(f"Teléfono: {telefono}\n")
            f.write(f"Dirección: {direccion}\n")
            f.write(f"Modelo: {seleccion}\n")
            f.write(f"Cantidad: {cantidad}\n")
            f.write(f"Total: ${total:.2f}\n")

        messagebox.showinfo("Éxito", f"Venta registrada por ${total:.2f}")
        ventana.destroy()

    tk.Button(marco, text="💾 Registrar Venta", bg="#1976d2", fg="white",
              font=("Arial", 14, "bold"), width=25, command=guardar_venta).grid(row=6, column=0, columnspan=2, pady=30)

    tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).place(relx=0.95, rely=0.03, anchor="ne")

def ver_ventas_vendedor():
    if not ventas_vendedor:
        messagebox.showinfo("Ventas", "No hay ventas registradas.")
        return

    mis_ventas = [v for v in ventas_vendedor if str(v['vendedor_id']) == str(usuario_actual['id'])]

    if not mis_ventas:
        messagebox.showinfo("Ventas", "No tienes ventas registradas.")
        return

    ventana = tk.Toplevel()
    ventana.title("Mis Ventas Registradas")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.pack(expand=True, fill="both", padx=100, pady=50)

    tk.Label(marco, text="Ventas Registradas", font=("Arial", 24, "bold"), bg="white").pack(pady=20)

    area = tk.Text(marco, font=("Arial", 14), wrap="word")
    area.pack(fill="both", expand=True)
    area.config(state="normal")

    for v in mis_ventas:
        texto = (
            f"ID Venta: {v['id']}\n"
            f"Cliente: {v['cliente']}\n"
            f"Teléfono: {v['telefono']}\n"
            f"Dirección: {v['direccion']}\n"
            f"Modelo: {v['modelo']}\n"
            f"Cantidad: {v['cantidad']}\n"
            f"Total: ${v['total']:.2f}\n"
            f"{'-'*40}\n"
        )
        area.insert(tk.END, texto)

    area.config(state="disabled")

    tk.Button(ventana, text="↩️ Regresar", bg="#d32f2f", fg="white",
              font=("Arial", 12, "bold"), command=ventana.destroy).place(relx=0.97, rely=0.03, anchor="ne")

# ----------------- Funciones auxiliares -----------------
def encriptar_clave(clave):
    return hashlib.sha256(clave.encode()).hexdigest()

def mostrar_texto(titulo, texto):
    ventana = tk.Toplevel()
    ventana.title(titulo)
    ventana.geometry("700x400")
    ventana.config(bg="white")
    text_widget = tk.Text(ventana, wrap='word', width=80, height=20, font=("Arial", 10))
    text_widget.insert('1.0', texto)
    text_widget.config(state='disabled')
    text_widget.pack(padx=10, pady=10)

# ----------------- Funciones empleados -----------------
def registrar_empleado():
    ventana = tk.Toplevel()
    ventana.title("Registrar Nuevo Empleado")
    ventana.state("zoomed")
    ventana.config(bg="#e6f2ff")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Registro de Empleado", font=("Arial", 24, "bold"), bg="white", fg="#333").grid(row=0, column=0, columnspan=2, pady=20)

    tk.Label(marco, text="Nombre del empleado:", font=("Arial", 16), bg="white").grid(row=1, column=0, sticky="e", pady=10)
    entrada_nombre = tk.Entry(marco, font=("Arial", 16), width=30)
    entrada_nombre.grid(row=1, column=1, pady=10)

    tk.Label(marco, text="Puesto:", font=("Arial", 16), bg="white").grid(row=2, column=0, sticky="e", pady=10)
    combo_puesto = ttk.Combobox(marco, values=["Vendedor", "Almacenista", "Gerente"], font=("Arial", 16), width=28, state="readonly")
    combo_puesto.grid(row=2, column=1, pady=10)

    tk.Label(marco, text="Contraseña:", font=("Arial", 16), bg="white").grid(row=3, column=0, sticky="e", pady=10)
    entrada_contrasena = tk.Entry(marco, show="*", font=("Arial", 16), width=30)
    entrada_contrasena.grid(row=3, column=1, pady=10)

    def guardar_empleado():
        nombre = entrada_nombre.get().strip()
        puesto = combo_puesto.get()
        contrasena = entrada_contrasena.get().strip()

        if not nombre or not puesto or not contrasena:
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
            return

        nuevo_id = max([emp['id'] for emp in empleados], default=0) + 1
        clave_encriptada = encriptar_clave(contrasena)
        nuevo_empleado = {'id': nuevo_id, 'nombre': nombre, 'puesto': puesto, 'contrasena': clave_encriptada}
        empleados.append(nuevo_empleado)

        with open(RUTA_EMPLEADOS, "a") as f:
            f.write(f"{nuevo_id},{nombre},{puesto},{clave_encriptada}\n")

        messagebox.showinfo("Éxito", "Empleado registrado exitosamente.")
        ventana.destroy()

    btn_guardar = tk.Button(marco, text="💾 Guardar", bg="#1976d2", fg="white",
                            font=("Arial", 16, "bold"), command=guardar_empleado, width=20)
    btn_guardar.grid(row=4, column=0, columnspan=2, pady=30)

    btn_cerrar = tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white",
                           font=("Arial", 14, "bold"), command=ventana.destroy)
    btn_cerrar.place(relx=0.95, rely=0.03, anchor="ne")

def editar_empleado():
    if not empleados:
        messagebox.showerror("Error", "No hay empleados registrados para editar.")
        return

    ventana = tk.Toplevel()
    ventana.title("Editar Empleado")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Editar Empleado", font=("Arial", 24, "bold"), bg="white").grid(row=0, column=0, columnspan=2, pady=20)

    opciones = [f"ID {e['id']} - {e['nombre']}" for e in empleados]
    combo_empleados = ttk.Combobox(marco, values=opciones, font=("Arial", 14), width=40, state="readonly")
    combo_empleados.grid(row=1, column=0, columnspan=2, pady=20)
    combo_empleados.current(0)

    campos = {}

    tk.Label(marco, text="Nombre:", bg="white", font=("Arial", 14)).grid(row=2, column=0, sticky="e", pady=10)
    entrada_nombre = tk.Entry(marco, font=("Arial", 14), width=30)
    entrada_nombre.grid(row=2, column=1, pady=10)
    campos['nombre'] = entrada_nombre

    tk.Label(marco, text="Puesto:", bg="white", font=("Arial", 14)).grid(row=3, column=0, sticky="e", pady=10)
    puestos = ["Gerente", "Almacenista", "Vendedor"]
    combo_puesto = ttk.Combobox(marco, values=puestos, font=("Arial", 14), width=28, state="readonly")
    combo_puesto.grid(row=3, column=1, pady=10)
    campos['puesto'] = combo_puesto

    tk.Label(marco, text="Nueva contraseña:", bg="white", font=("Arial", 14)).grid(row=4, column=0, sticky="e", pady=10)
    entrada_contra = tk.Entry(marco, font=("Arial", 14), show="*", width=30)
    entrada_contra.grid(row=4, column=1, pady=10)
    campos['contrasena'] = entrada_contra

    def cargar_datos(event=None):
        seleccion = combo_empleados.get()
        if not seleccion:
            return
        id_seleccion = int(seleccion.split()[1])
        emp = next((e for e in empleados if e['id'] == id_seleccion), None)
        if emp:
            campos['nombre'].delete(0, tk.END)
            campos['nombre'].insert(0, emp['nombre'])
            campos['puesto'].set(emp['puesto'])
            campos['contrasena'].delete(0, tk.END)

    combo_empleados.bind("<<ComboboxSelected>>", cargar_datos)
    cargar_datos()

    def guardar():
        seleccion = combo_empleados.get()
        if not seleccion:
            messagebox.showerror("Error", "Selecciona un empleado.")
            return
        id_seleccion = int(seleccion.split()[1])
        emp = next((e for e in empleados if e['id'] == id_seleccion), None)
        if not emp:
            messagebox.showerror("Error", "Empleado no encontrado.")
            return

        nuevo_nombre = campos['nombre'].get().strip()
        nuevo_puesto = campos['puesto'].get()
        nueva_contra = campos['contrasena'].get()

        if not nuevo_nombre:
            messagebox.showerror("Error", "El nombre no puede estar vacío.")
            return
        if nuevo_puesto not in puestos:
            messagebox.showerror("Error", "Selecciona un puesto válido.")
            return

        emp['nombre'] = nuevo_nombre
        emp['puesto'] = nuevo_puesto
        if nueva_contra:
            emp['contrasena'] = encriptar_clave(nueva_contra)

        with open(RUTA_EMPLEADOS, "w") as f:
            for e in empleados:
                f.write(f"{e['id']},{e['nombre']},{e['puesto']},{e['contrasena']}\n")

        messagebox.showinfo("Éxito", "Empleado actualizado correctamente.")
        ventana.destroy()

    tk.Button(marco, text="💾 Guardar cambios", bg="#1976d2", fg="white",
              font=("Arial", 14, "bold"), width=25, command=guardar).grid(row=5, column=0, columnspan=2, pady=30)
    
    tk.Button(marco, text="🗑 Eliminar Empleado", bg="#1976d2", fg="white",
              font=("Arial", 14, "bold"), width=25, command=eliminar_empleado).grid(row=7, column=0, columnspan=4, pady=32)

    tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).place(relx=0.95, rely=0.03, anchor="ne")


def ver_empleados():
    if not empleados:
        messagebox.showinfo("Empleados", "No hay empleados.")
        return

    ventana = tk.Toplevel()
    ventana.title("Lista de Empleados")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.pack(expand=True, fill="both", padx=100, pady=50)

    tk.Label(marco, text="Empleados Registrados", font=("Arial", 24, "bold"),
             bg="white", fg="#333").pack(pady=(0, 20))

    texto = "\n".join([f"ID: {e['id']} - {e['nombre']} ({e['puesto']})" for e in empleados])

    caja = tk.Text(marco, wrap="word", font=("Arial", 14))
    caja.insert("1.0", texto)
    caja.config(state="disabled", height=20)
    caja.pack(fill="both", expand=True)

    tk.Button(marco, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).pack(pady=20)

def eliminar_empleado():
    if not empleados:
        messagebox.showerror("Error", "No hay empleados registrados para eliminar.")
        return

    ventana = tk.Toplevel()
    ventana.title("Eliminar Empleado")
    ventana.geometry("800x600")
    ventana.config(bg="#f0f0f0")

    tk.Label(ventana, text="Eliminar Empleado", font=("Arial", 24, "bold"), bg="#f0f0f0").pack(pady=20)

    opciones = [f"ID {e['id']} - {e['nombre']}" for e in empleados]
    combo_empleados = ttk.Combobox(ventana, values=opciones, font=("Arial", 16), state="readonly", width=40)
    combo_empleados.pack(pady=20)
    combo_empleados.current(0)

    def eliminar():
        seleccion = combo_empleados.get()
        if not seleccion:
            messagebox.showerror("Error", "Selecciona un empleado.")
            return
        id_seleccion = int(seleccion.split()[1])
        confirmar = messagebox.askyesno("Confirmar", f"¿Seguro que quieres eliminar al empleado ID {id_seleccion}?")
        if confirmar:
            global empleados
            empleados = [e for e in empleados if e['id'] != id_seleccion]
            with open(RUTA_EMPLEADOS, "w") as f:
                for e in empleados:
                    f.write(f"{e['id']},{e['nombre']},{e['puesto']},{e['contrasena']}\n")
            messagebox.showinfo("Éxito", "Empleado eliminado correctamente.")
            ventana.destroy()

    tk.Button(ventana, text="🗑 Eliminar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=eliminar).pack(pady=10)

    tk.Button(ventana, text="↩️ Regresar", bg="#5d2fd3", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).pack(pady=5)

# ----------------- Funciones para llantas -----------------
def ver_inventario():
    if not llantas:
        messagebox.showinfo("Inventario", "No hay llantas registradas.")
        return

    ventana = tk.Toplevel()
    ventana.title("Inventario de Llantas")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=60, pady=40)
    marco.pack(expand=True, fill="both", padx=100, pady=50)

    tk.Label(marco, text="Inventario de Llantas", font=("Arial", 24, "bold"), bg="white").pack(pady=20)

    modelos = [f"{l['marca']} {l['modelo']}" for l in llantas]
    combo_modelos = ttk.Combobox(marco, values=modelos, font=("Arial", 14), state="readonly", width=50)
    combo_modelos.pack(pady=10)

    detalles_var = tk.StringVar()
    lbl_detalles = tk.Label(marco, textvariable=detalles_var, bg="white", justify="left", font=("Arial", 14))
    lbl_detalles.pack(pady=20)

    def mostrar_detalles():
        seleccion = combo_modelos.get()
        llanta = next((l for l in llantas if f"{l['marca']} {l['modelo']}" == seleccion), None)
        if llanta:
            texto = (f"Marca: {llanta['marca']}\n"
                     f"Modelo: {llanta['modelo']}\n"
                     f"Precio: ${llanta['precio']:.2f}\n"
                     f"Stock: {llanta['stock']}\n"
                     f"Tipo de Vehículo: {llanta['tipo_vehiculo']}\n"
                     f"Tipo de Uso: {llanta['tipo_uso']}\n"
                     f"Medidas: {llanta['ancho']}/{llanta['perfil']} R{llanta['diametro']}\n"
                     f"Caducidad: {llanta['caducidad']}\n")
            detalles_var.set(texto)

    combo_modelos.bind("<<ComboboxSelected>>", mostrar_detalles)
    if modelos:
        combo_modelos.current(0)
        mostrar_detalles()

    tk.Button(marco, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).pack(pady=30)


def buscar_llanta():
    if not llantas:
        messagebox.showinfo("Buscar llanta", "No hay llantas registradas.")
        return

    ventana = tk.Toplevel()
    ventana.title("Buscar Llanta")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.pack(expand=True, fill="both", padx=100, pady=50)

    tk.Label(marco, text="Buscar Llanta", font=("Arial", 24, "bold"), bg="white").pack(pady=(0, 30))

    # Selección del tipo de búsqueda
    tk.Label(marco, text="Buscar por:", font=("Arial", 14), bg="white").pack()
    opciones_busqueda = ["Modelo", "Tipo de Vehículo", "Tipo de Uso"]
    combo_tipo = ttk.Combobox(marco, values=opciones_busqueda, state="readonly", font=("Arial", 14), width=30)
    combo_tipo.pack(pady=10)
    combo_tipo.current(0)

    # Segundo combo que se llenará automáticamente
    combo_valores = ttk.Combobox(marco, state="readonly", font=("Arial", 14), width=30)
    combo_valores.pack(pady=10)

    # Área de resultados
    resultado = tk.Text(marco, font=("Arial", 13), height=20, wrap="word")
    resultado.pack(pady=20)
    resultado.config(state="disabled")

    # Función para actualizar el segundo combobox según el tipo de búsqueda
    def actualizar_valores(event=None):
        tipo = combo_tipo.get()
        valores = []

        if tipo == "Modelo":
            valores = list(sorted(set(l['modelo'] for l in llantas)))
        elif tipo == "Tipo de Vehículo":
            valores = list(sorted(set(l['tipo_vehiculo'] for l in llantas)))
        elif tipo == "Tipo de Uso":
            valores = list(sorted(set(l['tipo_uso'] for l in llantas)))

        combo_valores['values'] = valores
        if valores:
            combo_valores.current(0)

    combo_tipo.bind("<<ComboboxSelected>>", actualizar_valores)
    actualizar_valores()

    # Función de búsqueda
    def buscar():
        tipo = combo_tipo.get()
        valor = combo_valores.get()

        if not valor:
            messagebox.showwarning("Atención", "Selecciona una opción para buscar.")
            return

        resultado.config(state="normal")
        resultado.delete("1.0", tk.END)

        coincidencias = []
        for l in llantas:
            if tipo == "Modelo" and l['modelo'] == valor:
                coincidencias.append(l)
            elif tipo == "Tipo de Vehículo" and l['tipo_vehiculo'] == valor:
                coincidencias.append(l)
            elif tipo == "Tipo de Uso" and l['tipo_uso'] == valor:
                coincidencias.append(l)

        if coincidencias:
            for l in coincidencias:
                texto_llanta = (
                    f"Marca: {l['marca']}\n"
                    f"Modelo: {l['modelo']}\n"
                    f"Precio: ${l['precio']:.2f}\n"
                    f"Stock: {l['stock']}\n"
                    f"Tipo Vehículo: {l['tipo_vehiculo']}\n"
                    f"Tipo Uso: {l['tipo_uso']}\n"
                    f"Medidas: {l['ancho']}/{l['perfil']} R{l['diametro']}\n"
                    f"Caducidad: {l['caducidad']}\n"
                    f"{'-'*50}\n"
                )
                resultado.insert(tk.END, texto_llanta)
        else:
            resultado.insert(tk.END, "No se encontraron llantas con ese criterio.")

        resultado.config(state="disabled")

    # Botones
    tk.Button(marco, text="🔍 Buscar", bg="#1976d2", fg="white",
              font=("Arial", 14, "bold"), width=20, command=buscar).pack(pady=10)

    tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).place(relx=0.95, rely=0.03, anchor="ne")


def registrar_llanta():
    ventana = tk.Toplevel()
    ventana.title("Registrar Llanta")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")
    
    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Registro de Nueva Llanta", font=("Arial", 24, "bold"), bg="white").grid(row=0, column=0, columnspan=2, pady=20)

    campos = {}

    etiquetas_entry = ["Marca", "Modelo", "Precio", "Stock"]
    for i, campo in enumerate(etiquetas_entry):
        tk.Label(marco, text=campo + ":", bg="white", font=("Arial", 14)).grid(row=i+1, column=0, sticky="e", pady=10)
        entrada = tk.Entry(marco, font=("Arial", 14), width=30)
        entrada.grid(row=i+1, column=1, pady=10)
        campos[campo.lower()] = entrada

    # Campo de fecha de caducidad
    fila_caducidad = len(etiquetas_entry) + 1
    tk.Label(marco, text="Fecha de caducidad (YYYY-MM-DD):", bg="white", font=("Arial", 14)).grid(row=fila_caducidad, column=0, sticky="e", pady=10)
    entrada_caducidad = tk.Entry(marco, font=("Arial", 14), width=30)
    entrada_caducidad.grid(row=fila_caducidad, column=1, pady=10)
    campos['caducidad'] = entrada_caducidad

    # Comboboxes
    opciones = {
        'tipo_vehiculo': ["Auto", "Camioneta", "Camión", "Motocicleta", "SUV"],
        'tipo_uso': ["Verano", "Invierno", "Todo terreno", "All Season"],
        'ancho': [str(x) for x in range(155, 326, 5)],
        'perfil': [str(x) for x in range(30, 81, 5)],
        'diametro': [str(x) for x in range(13, 23)],
    }

    etiquetas_combo = ["Tipo Vehículo", "Tipo Uso", "Ancho", "Perfil", "Diámetro"]
    fila_base = fila_caducidad + 1  # empieza después del campo de caducidad

    for i, (clave, etiqueta) in enumerate(zip(opciones.keys(), etiquetas_combo)):
        tk.Label(marco, text=etiqueta + ":", bg="white", font=("Arial", 14)).grid(row=fila_base + i, column=0, sticky="e", pady=10)
        combo = ttk.Combobox(marco, values=opciones[clave], font=("Arial", 14), width=28, state="readonly")
        combo.current(0)
        combo.grid(row=fila_base + i, column=1, pady=10)
        campos[clave] = combo

    def guardar():
        try:
            # Validar y convertir la fecha
            fecha_str = campos['caducidad'].get()
            caducidad = datetime.strptime(fecha_str, "%Y-%m-%d").date()
            
            nueva = {
                'marca': campos['marca'].get().strip(),
                'modelo': campos['modelo'].get().strip(),
                'precio': float(campos['precio'].get()),
                'stock': int(campos['stock'].get()),
                'caducidad': caducidad,
                'tipo_vehiculo': campos['tipo_vehiculo'].get(),
                'tipo_uso': campos['tipo_uso'].get(),
                'ancho': int(campos['ancho'].get()),
                'perfil': int(campos['perfil'].get()),
                'diametro': int(campos['diametro'].get())
            }
            if not nueva['marca'] or not nueva['modelo']:
                messagebox.showerror("Error", "Marca y Modelo son obligatorios.")
                return
        except ValueError:
            messagebox.showerror("Error", "Precio, Stock y medidas deben ser válidos.")
            return

        llantas.append(nueva)
        guardar_llantas()
        messagebox.showinfo("Éxito", "Llanta registrada correctamente.")
        ventana.destroy()

    tk.Button(marco, text="💾 Guardar", bg="#1976d2", fg="white", font=("Arial", 16, "bold"), width=20,
              command=guardar).grid(row=11, column=0, columnspan=2, pady=30)

    tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white", font=("Arial", 14, "bold"),
              command=ventana.destroy).place(relx=0.95, rely=0.03, anchor="ne")


def editar_llanta():
    if not llantas:
        messagebox.showinfo("Editar llanta", "No hay llantas registradas.")
        return

    ventana = tk.Toplevel()
    ventana.title("Editar Llanta")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Editar Información de Llanta", font=("Arial", 24, "bold"), bg="white").grid(row=0, column=0, columnspan=2, pady=20)

    modelos = [f"{l['marca']} {l['modelo']}" for l in llantas]
    combo_modelos = ttk.Combobox(marco, values=modelos, font=("Arial", 14), state="readonly", width=40)
    combo_modelos.grid(row=1, column=0, columnspan=2, pady=10)
    combo_modelos.current(0)

    campos = {}
    etiquetas = ["Marca", "Modelo", "Precio", "Stock", "Caducidad"]
    for i, etiqueta in enumerate(etiquetas):
        tk.Label(marco, text=etiqueta + ":", bg="white", font=("Arial", 14)).grid(row=i+2, column=0, sticky="e", pady=10)
        entrada = tk.Entry(marco, font=("Arial", 14), width=30)
        entrada.grid(row=i+2, column=1, pady=10)
        campos[etiqueta.lower()] = entrada

    def cargar_info(event=None):
        seleccion = combo_modelos.get()
        llanta = next((l for l in llantas if f"{l['marca']} {l['modelo']}" == seleccion), None)
        if llanta:
            campos['marca'].delete(0, tk.END)
            campos['marca'].insert(0, llanta['marca'])

            campos['modelo'].delete(0, tk.END)
            campos['modelo'].insert(0, llanta['modelo'])

            campos['precio'].delete(0, tk.END)
            campos['precio'].insert(0, str(llanta['precio']))

            campos['stock'].delete(0, tk.END)
            campos['stock'].insert(0, str(llanta['stock']))

            campos['caducidad'].delete(0, tk.END)
            campos['caducidad'].insert(0, llanta['caducidad'].strftime("%Y-%m-%d"))

    combo_modelos.bind("<<ComboboxSelected>>", cargar_info)
    cargar_info()

    def guardar():
        seleccion = combo_modelos.get()
        llanta = next((l for l in llantas if f"{l['marca']} {l['modelo']}" == seleccion), None)
        if not llanta:
            messagebox.showerror("Error", "Llanta no encontrada.")
            return

        try:
            nueva_marca = campos['marca'].get().strip()
            nuevo_modelo = campos['modelo'].get().strip()
            nuevo_precio = float(campos['precio'].get())
            nuevo_stock = int(campos['stock'].get())
            nueva_caducidad = datetime.strptime(campos['caducidad'].get(), "%Y-%m-%d").date()

            if not nueva_marca or not nuevo_modelo:
                raise ValueError("Marca y modelo no pueden estar vacíos.")

        except ValueError as e:
            messagebox.showerror("Error", f"Datos inválidos: {e}")
            return

        llanta['marca'] = nueva_marca
        llanta['modelo'] = nuevo_modelo
        llanta['precio'] = nuevo_precio
        llanta['stock'] = nuevo_stock
        llanta['caducidad'] = nueva_caducidad

        guardar_llantas()
        messagebox.showinfo("Éxito", "Llanta actualizada correctamente.")
        ventana.destroy()

    tk.Button(marco, text="💾 Guardar Cambios", bg="#1976d2", fg="white", font=("Arial", 14, "bold"),
              width=25, command=guardar).grid(row=7, column=0, columnspan=2, pady=30)

    tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).place(relx=0.95, rely=0.03, anchor="ne")


def eliminar_llanta():
    modelo = simpledialog.askstring("Eliminar", "Modelo de llanta a eliminar:")
    if not modelo:
        return
    global llantas
    nuevas = [l for l in llantas if l['modelo'] != modelo]
    if len(nuevas) == len(llantas):
        messagebox.showerror("Error", "Modelo no encontrado.")
        return
    llantas = nuevas
    guardar_llantas()
    messagebox.showinfo("Éxito", "Llanta eliminada.")

# ----------------- Funciones para pedidos -----------------
def registrar_pedido():
    if not llantas:
        messagebox.showerror("Error", "No hay llantas registradas. Registre llantas primero.")
        return

    ventana = tk.Toplevel()
    ventana.title("Registrar Pedido")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Registrar Pedido", font=("Arial", 24, "bold"),
             bg="white", fg="#333").grid(row=0, column=0, columnspan=2, pady=(0, 30))

    campos = {}

    # Proveedor
    tk.Label(marco, text="Proveedor:", bg="white", font=("Arial", 14)).grid(row=1, column=0, sticky="e", pady=10, padx=10)
    entrada_proveedor = tk.Entry(marco, font=("Arial", 14), width=30)
    entrada_proveedor.grid(row=1, column=1, pady=10)
    campos['proveedor'] = entrada_proveedor

    # Costo
    tk.Label(marco, text="Costo Total:", bg="white", font=("Arial", 14)).grid(row=2, column=0, sticky="e", pady=10, padx=10)
    entrada_costo = tk.Entry(marco, font=("Arial", 14), width=30)
    entrada_costo.grid(row=2, column=1, pady=10)
    campos['costo'] = entrada_costo

    # Cantidad
    tk.Label(marco, text="Cantidad:", bg="white", font=("Arial", 14)).grid(row=3, column=0, sticky="e", pady=10, padx=10)
    entrada_cantidad = tk.Entry(marco, font=("Arial", 14), width=30)
    entrada_cantidad.grid(row=3, column=1, pady=10)
    campos['cantidad'] = entrada_cantidad

    # Modelo (Combobox)
    tk.Label(marco, text="Modelo:", bg="white", font=("Arial", 14)).grid(row=4, column=0, sticky="e", pady=10, padx=10)
    modelos = [l['modelo'] for l in llantas]
    combo_modelo = ttk.Combobox(marco, values=modelos, state="readonly", font=("Arial", 14), width=28)
    combo_modelo.grid(row=4, column=1, pady=10)
    combo_modelo.current(0)
    campos['modelo'] = combo_modelo

    # Vista previa
    vista_prev = tk.StringVar()
    tk.Label(marco, textvariable=vista_prev, bg="white", fg="#007acc", font=("Arial", 12, "italic")
            ).grid(row=5, column=0, columnspan=2, pady=10)

    def actualizar_preview(event=None):
        modelo = combo_modelo.get()
        l = next((ll for ll in llantas if ll['modelo'] == modelo), None)
        if l:
            vista_prev.set(f"{l['marca']} {l['modelo']} - {l['ancho']}/{l['perfil']} R{l['diametro']} - ${l['precio']:.2f}")

    combo_modelo.bind("<<ComboboxSelected>>", actualizar_preview)
    actualizar_preview()

    def guardar():
        proveedor = campos['proveedor'].get().strip()
        costo_text = campos['costo'].get().strip()
        cantidad_text = campos['cantidad'].get().strip()
        modelo = campos['modelo'].get()

        if not proveedor:
            messagebox.showerror("Error", "Proveedor es obligatorio.")
            return

        try:
            costo = float(costo_text)
            cantidad = int(cantidad_text)
        except ValueError:
            messagebox.showerror("Error", "Costo debe ser número decimal y cantidad entero.")
            return

        global siguiente_pedido
        nuevo = {
            'id': siguiente_pedido,
            'proveedor': proveedor,
            'costo': costo,
            'estado': 'Pendiente',
            'cantidad': cantidad,
            'modelo': modelo
        }
        pedidos.append(nuevo)
        siguiente_pedido += 1
        guardar_pedidos()
        messagebox.showinfo("Éxito", "Pedido registrado.")
        ventana.destroy()

    # Botones
    tk.Button(marco, text="💾 Guardar", bg="#1976d2", fg="white",
              font=("Arial", 14, "bold"), width=20, command=guardar).grid(row=6, column=0, pady=30)

    tk.Button(marco, text="❌ Cancelar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), width=20, command=ventana.destroy).grid(row=6, column=1, pady=30)

    # Botón cerrar arriba a la derecha (opcional)
    tk.Button(ventana, text="✖", bg="#d32f2f", fg="white",
              font=("Arial", 12, "bold"), command=ventana.destroy).place(relx=0.97, rely=0.03, anchor="ne")



def ver_pedidos():
    if not pedidos:
        messagebox.showinfo("Pedidos", "No hay pedidos registrados.")
        return

    ventana = tk.Toplevel()
    ventana.title("Lista de Pedidos")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.pack(expand=True, fill="both", padx=100, pady=50)

    tk.Label(marco, text="Lista de Pedidos", font=("Arial", 24, "bold"), bg="white").pack(pady=20)

    area = tk.Text(marco, font=("Arial", 14), height=25, wrap="word")
    area.pack(expand=True, fill="both")
    area.config(state="normal")

    for p in pedidos:
        texto = (
            f"ID: {p['id']}\n"
            f"Modelo: {p['modelo']}\n"
            f"Cantidad: {p['cantidad']}\n"
            f"Estado: {p['estado']}\n"
            f"{'-'*40}\n"
        )
        area.insert(tk.END, texto)

    area.config(state="disabled")

    tk.Button(ventana, text="✖ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 12, "bold"), command=ventana.destroy).place(relx=0.97, rely=0.03, anchor="ne")


def cambiar_estado_pedido():
    if not pedidos:
        messagebox.showinfo("Pedidos", "No hay pedidos registrados.")
        return

    ventana = tk.Toplevel()
    ventana.title("Cambiar Estado de Pedido")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text="Cambiar Estado de Pedido", font=("Arial", 24, "bold"), bg="white").pack(pady=20)

    ids = [str(p['id']) for p in pedidos if p['estado'] != "Éxito"]
    if not ids:
        messagebox.showinfo("Pedidos", "No hay pedidos pendientes.")
        ventana.destroy()
        return

    combo = ttk.Combobox(marco, values=ids, font=("Arial", 14), width=30, state="readonly")
    combo.pack(pady=10)
    combo.current(0)

    def cambiar_estado():
        pid = int(combo.get())
        pedido = next((p for p in pedidos if p['id'] == pid), None)
        if not pedido:
            return

        pedido['estado'] = "Éxito"

        # Aumentar stock
        modelo = pedido['modelo']
        cantidad = pedido['cantidad']
        for l in llantas:
            if l['modelo'] == modelo:
                l['stock'] += cantidad
                break

        guardar_pedidos()
        guardar_llantas()
        messagebox.showinfo("Éxito", f"Pedido {pid} actualizado y stock incrementado.")
        ventana.destroy()

    tk.Button(marco, text="✅ Cambiar a Éxito", bg="#388e3c", fg="white",
              font=("Arial", 14, "bold"), command=cambiar_estado).pack(pady=30)

    tk.Button(ventana, text="❌ Cerrar", bg="#d32f2f", fg="white",
              font=("Arial", 14, "bold"), command=ventana.destroy).place(relx=0.95, rely=0.03, anchor="ne")

def ver_tickets_generados():
    if not os.path.exists(RUTA_TICKETS):
        messagebox.showinfo("Tickets", "No hay tickets generados aún.")
        return

    archivos = sorted([f for f in os.listdir(RUTA_TICKETS) if f.endswith(".txt")])
    if not archivos:
        messagebox.showinfo("Tickets", "No hay tickets guardados.")
        return

    ventana = tk.Toplevel()
    ventana.title("Tickets Generados")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    lista = tk.Listbox(ventana, font=("Courier", 10))
    lista.pack(fill="both", expand=False, padx=10, pady=(10, 0), ipady=5)

    for nombre in archivos:
        lista.insert("end", nombre)

    texto = tk.Text(ventana, wrap="word", font=("Courier", 10))
    texto.pack(fill="both", expand=True, padx=10, pady=10)
    texto.config(state="disabled")

    def mostrar_ticket(event=None):
        if not lista.curselection():
            return
        seleccion = lista.get(lista.curselection())
        ruta = os.path.join(RUTA_TICKETS, seleccion)
        with open(ruta, "r", encoding="utf-8") as f:
            contenido = f.read()
        texto.config(state="normal")
        texto.delete("1.0", "end")
        texto.insert("1.0", contenido)
        texto.config(state="disabled")

    lista.bind("<<ListboxSelect>>", mostrar_ticket)

    frame_botones = tk.Frame(ventana, bg="#f0f0f0")
    frame_botones.pack(pady=(0, 15))

    def buscar_ticket():
        id_venta = simpledialog.askinteger("Buscar Ticket", "Ingresa el ID de la venta:")
        if id_venta is None:
            return
        nombre_archivo = f"ticket_{id_venta:04d}.txt"
        if nombre_archivo in archivos:
            index = archivos.index(nombre_archivo)
            lista.selection_clear(0, tk.END)
            lista.selection_set(index)
            lista.activate(index)
            lista.see(index)
            mostrar_ticket()
        else:
            messagebox.showerror("No encontrado", f"No se encontró el ticket con ID {id_venta}.")

    def eliminar_ticket():
        id_venta = simpledialog.askinteger("Eliminar Ticket", "Ingresa el ID de la venta a eliminar:")
        if id_venta is None:
            return
        nombre_archivo = f"ticket_{id_venta:04d}.txt"
        ruta = os.path.join(RUTA_TICKETS, nombre_archivo)
        if not os.path.exists(ruta):
            messagebox.showerror("No encontrado", f"No existe el ticket con ID {id_venta}.")
            return
        confirmar = messagebox.askyesno("Confirmar", f"¿Eliminar el ticket {nombre_archivo}?")
        if confirmar:
            os.remove(ruta)
            messagebox.showinfo("Éxito", "Ticket eliminado correctamente.")
            ventana.destroy()
            ver_tickets_generados()

    tk.Button(frame_botones, text="🔍 Buscar por ID", command=buscar_ticket,
              bg="#1976d2", fg="white", font=("Arial", 10, "bold"), width=18).grid(row=0, column=0, padx=10)

    tk.Button(frame_botones, text="🗑️ Eliminar por ID", command=eliminar_ticket,
              bg="#d32f2f", fg="white", font=("Arial", 10, "bold"), width=18).grid(row=0, column=1, padx=10)
    
    tk.Button(frame_botones, text="↩️Regresar", command=ventana.destroy,
              bg="#d32f2f", fg="white", font=("Arial", 10, "bold"), width=18).grid(row=0, column=2, padx=10)


# ----------------- Función para abrir menú por rol -----------------
def abrir_menu_por_rol(empleado):
    ventana = tk.Toplevel()
    ventana.title(f"Menú - {empleado['puesto']}")
    ventana.state("zoomed")
    ventana.config(bg="#f0f0f0")

    marco = tk.Frame(ventana, bg="white", padx=40, pady=40)
    marco.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(marco, text=f"Bienvenido, {empleado['nombre']}", font=("Arial", 28, "bold"),
             bg="white", fg="#333").grid(row=0, column=0, columnspan=3, pady=(0, 40))

    def boton(texto, comando, fila, columna, color="#1976d2"):
        btn = tk.Button(marco, text=texto, font=("Arial", 14, "bold"), bg=color, fg="white",
                        width=25, height=2, command=comando)
        btn.grid(row=fila, column=columna, padx=20, pady=20)

    puesto = empleado['puesto']

    if puesto == "Gerente":
        # Fila 1
        boton("👥 Registrar Empleado", registrar_empleado, 1, 0)
        boton("✏️ Editar Empleado", editar_empleado, 1, 1)
        boton("🔍 Ver Empleados", ver_empleados, 1, 2)
        # Fila 2
        boton("📦 Ver Inventario", ver_inventario, 2, 0)
        boton("📥 Buscar Llanta", buscar_llanta, 2, 1)
        boton("🛒 Registrar Llanta", registrar_llanta, 2, 2)
        # Fila 3
        boton("🛠️ Editar Llanta", editar_llanta, 3, 0)
        boton("📑 Ver Pedidos", ver_pedidos, 3, 1)
        boton("✅ Cambiar Estado Pedido", cambiar_estado_pedido, 3, 2)
        # Fila 4
        boton("📥 Registrar Pedido", registrar_pedido, 4, 0)
        boton("Eliminar Llanta", eliminar_llanta, 4, 1)
        tk.Button(ventana, text="↩️Cerrar Sesión", bg="#d32f2f", fg="white",
              font=("Arial", 12, "bold"), command=ventana.destroy).place(relx=0.97, rely=0.03, anchor="ne")
        

    elif puesto == "Vendedor":
        # Fila 1
        boton("🛒 Registrar Venta", lambda: registrar_venta_vendedor(empleado['id']), 1, 0)
        boton("📄 Ver Mis Ventas", ver_ventas_vendedor, 1, 1)
        boton("📥 Buscar Llanta", buscar_llanta, 1, 2)
        # Fila 2
        boton("📦 Ver Inventario", ver_inventario, 2, 0)
        boton("🎟 Ver Tickets", ver_tickets_generados, 2, 1)
        boton("↩️ Cerrar Sesión", ventana.destroy, 2, 2, "#d32f2f")

    elif puesto == "Almacenista":
        # Fila 1
        boton("📦 Ver Inventario", ver_inventario, 1, 0)
        boton("📥 Buscar Llanta", buscar_llanta, 1, 1)
        boton("🛒 Registrar Llanta", registrar_llanta, 1, 2)
        # Fila 2
        boton("🛠️ Editar Llanta", editar_llanta, 2, 0)
        boton("📥 Registrar Pedido", registrar_pedido, 2, 1)
        boton("↩️ Cerrar Sesión", ventana.destroy, 2, 2, "#d32f2f")

    else:
        messagebox.showerror("Error", "Rol no reconocido.")
        ventana.destroy()

# ----------------- Función para iniciar sesión -----------------
def iniciar_sesion():
    global intentos_fallidos

    id_ = simpledialog.askinteger("Inicio", "ID:")
    clave = simpledialog.askstring("Inicio", "Contraseña:")
    if not id_ or not clave:
        return

    if intentos_fallidos.get(id_, 0) >= 3:
        messagebox.showerror("Bloqueado", "Esta cuenta ha sido bloqueada por demasiados intentos fallidos.")
        return

    clave_hash = encriptar_clave(clave)

    for emp in empleados:
     if emp['id'] == id_:
        if emp['contrasena'] == clave_hash:
            intentos_fallidos[id_] = 0  # Reiniciar intentos si fue exitoso
            global usuario_actual
            usuario_actual = emp    # Guardar usuario actual para usar luego
            abrir_menu_por_rol(emp)
            return
        else:
            break

    # Si no coincide o no existe
    intentos_fallidos[id_] = intentos_fallidos.get(id_, 0) + 1
    restantes = 3 - intentos_fallidos[id_]
    if restantes > 0:
        messagebox.showerror("Error", f"Credenciales incorrectas. Intentos restantes: {restantes}")
    else:
        messagebox.showerror("Bloqueado", "Cuenta bloqueada tras 3 intentos fallidos.")

# ----------------- Interfaz principal -----------------

URL_FONDO = "https://i.pinimg.com/736x/43/9f/90/439f9056e4a392b5465dbfa4be45f753.jpg"  # Puedes cambiar la URL

def main():
    cargar_empleados()
    cargar_llantas()
    cargar_pedidos()
    cargar_ventas_vendedor()


    root = tk.Tk()
    root.title("Sistema de Llantera")
    root.geometry("800x600")

    try:
        response = requests.get(URL_FONDO)
        response.raise_for_status()
        fondo_img = Image.open(BytesIO(response.content))
        fondo_img = fondo_img.resize((800, 600))
        fondo_tk = ImageTk.PhotoImage(fondo_img)

        fondo_label = tk.Label(root, image=fondo_tk)
        fondo_label.place(x=0, y=0, relwidth=1, relheight=1)
        root.fondo_tk = fondo_tk  # mantener referencia
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo cargar la imagen de fondo: {e}")
        root.config(bg="lightgray")

    if not empleados:
        messagebox.showinfo("Primer uso", "No hay empleados registrados. Crea el primer empleado (Gerente).")
        registrar_empleado()

    # Título
    tk.Label(root, text="Sistema de Gestión de Llantera",
             fg="white", bg="black", font=("Arial", 16, "bold")).place(relx=0.5, rely=0.15, anchor="center")

    # Botones centrados y grandes
    tk.Button(root, text="Iniciar Sesión", width=30,
              bg="#4caf50", fg="white", font=("Arial", 14, "bold"),
              command=iniciar_sesion).place(relx=0.5, rely=0.35, anchor="center")

    tk.Button(root, text="Salir", width=30,
              bg="#f44336", fg="white", font=("Arial", 14, "bold"),
              command=root.quit).place(relx=0.5, rely=0.45, anchor="center")
    


    root.mainloop()

if __name__ == "__main__":
    main()
